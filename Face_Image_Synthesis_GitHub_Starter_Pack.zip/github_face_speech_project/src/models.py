"""Conditional GAN networks (TensorFlow/Keras)."""
import tensorflow as tf
from tensorflow.keras import layers

IMAGE_SIZE = 128
FEATURE_DIM = 40 * 32
LATENT_DIM = 128


def build_generator():
    condition = layers.Input((FEATURE_DIM,), name="audio_condition")
    noise = layers.Input((LATENT_DIM,), name="latent_noise")
    x = layers.Concatenate()([condition, noise])
    x = layers.Dense(8 * 8 * 256, use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)
    x = layers.Reshape((8, 8, 256))(x)
    for filters in (256, 128, 64, 32):
        x = layers.UpSampling2D()(x)
        x = layers.Conv2D(filters, 3, padding="same", use_bias=False)(x)
        x = layers.BatchNormalization()(x)
        x = layers.ReLU()(x)
    image = layers.Conv2D(3, 3, padding="same", activation="tanh", name="synthetic_face")(x)
    return tf.keras.Model([condition, noise], image, name="conditional_generator")


def build_discriminator():
    image = layers.Input((IMAGE_SIZE, IMAGE_SIZE, 3), name="face_image")
    condition = layers.Input((FEATURE_DIM,), name="audio_condition")
    c = layers.Dense(IMAGE_SIZE * IMAGE_SIZE, activation="relu")(condition)
    c = layers.Reshape((IMAGE_SIZE, IMAGE_SIZE, 1))(c)
    x = layers.Concatenate()([image, c])
    for filters in (64, 128, 256, 512):
        x = layers.Conv2D(filters, 4, strides=2, padding="same")(x)
        x = layers.LeakyReLU(0.2)(x)
        x = layers.Dropout(0.3)(x)
    x = layers.Flatten()(x)
    output = layers.Dense(1, activation="sigmoid")(x)
    return tf.keras.Model([image, condition], output, name="conditional_discriminator")
