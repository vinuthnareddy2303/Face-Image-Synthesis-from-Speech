"""Audio preprocessing utilities."""
from pathlib import Path
import numpy as np
import librosa

SAMPLE_RATE = 16_000
N_MFCC = 40
FEATURE_FRAMES = 32


def extract_audio_features(audio_path: str | Path) -> np.ndarray:
    """Return a fixed-size MFCC condition vector for a WAV/audio file."""
    signal, sr = librosa.load(str(audio_path), sr=SAMPLE_RATE, mono=True)
    if signal.size == 0:
        raise ValueError(f"Audio file is empty: {audio_path}")
    mfcc = librosa.feature.mfcc(y=signal, sr=sr, n_mfcc=N_MFCC)
    # Preserve a short temporal summary by resizing the time axis consistently.
    if mfcc.shape[1] < FEATURE_FRAMES:
        mfcc = np.pad(mfcc, ((0, 0), (0, FEATURE_FRAMES - mfcc.shape[1])))
    else:
        indices = np.linspace(0, mfcc.shape[1] - 1, FEATURE_FRAMES).astype(int)
        mfcc = mfcc[:, indices]
    features = mfcc.astype(np.float32)
    mean = features.mean(axis=1, keepdims=True)
    std = features.std(axis=1, keepdims=True) + 1e-6
    features = (features - mean) / std
    return features.reshape(-1)
