"""Speech-conditioned face synthesis project."""
