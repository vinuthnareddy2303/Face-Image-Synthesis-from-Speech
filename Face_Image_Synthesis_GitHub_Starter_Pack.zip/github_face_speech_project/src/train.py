"""Train the speech-conditioned cGAN baseline."""
import argparse
from pathlib import Path
import tensorflow as tf
from .dataset import make_dataset
from .models import build_generator, build_discriminator, LATENT_DIM


def train(manifest, epochs=50, batch_size=16, checkpoint_dir="models/cgan"):
    dataset, count = make_dataset(manifest, batch_size=batch_size)
    if count < 2:
        raise ValueError("At least two paired examples are required for training.")
    generator = build_generator()
    discriminator = build_discriminator()
    g_opt = tf.keras.optimizers.Adam(learning_rate=2e-4, beta_1=0.5)
    d_opt = tf.keras.optimizers.Adam(learning_rate=2e-4, beta_1=0.5)
    bce = tf.keras.losses.BinaryCrossentropy()

    @tf.function
    def train_step(real_images, conditions):
        batch = tf.shape(real_images)[0]
        noise = tf.random.normal((batch, LATENT_DIM))
        with tf.GradientTape() as d_tape, tf.GradientTape() as g_tape:
            fake_images = generator([conditions, noise], training=True)
            real_scores = discriminator([real_images, conditions], training=True)
            fake_scores = discriminator([fake_images, conditions], training=True)
            d_loss = bce(tf.ones_like(real_scores) * 0.9, real_scores) + bce(tf.zeros_like(fake_scores), fake_scores)
            g_loss = bce(tf.ones_like(fake_scores), fake_scores)
        d_grads = d_tape.gradient(d_loss, discriminator.trainable_variables)
        g_grads = g_tape.gradient(g_loss, generator.trainable_variables)
        d_opt.apply_gradients(zip(d_grads, discriminator.trainable_variables))
        g_opt.apply_gradients(zip(g_grads, generator.trainable_variables))
        return d_loss, g_loss

    ckpt_dir = Path(checkpoint_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = tf.train.Checkpoint(generator=generator, discriminator=discriminator,
                                     g_optimizer=g_opt, d_optimizer=d_opt)
    manager = tf.train.CheckpointManager(checkpoint, str(ckpt_dir), max_to_keep=3)
    for epoch in range(1, epochs + 1):
        d_metric, g_metric = tf.keras.metrics.Mean(), tf.keras.metrics.Mean()
        for real_images, conditions in dataset:
            d_loss, g_loss = train_step(real_images, conditions)
            d_metric.update_state(d_loss)
            g_metric.update_state(g_loss)
        print(f"Epoch {epoch:03d}/{epochs} | D loss: {d_metric.result():.4f} | G loss: {g_metric.result():.4f}")
        manager.save(checkpoint_number=epoch)
    print(f"Training complete. Checkpoints: {ckpt_dir.resolve()}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--checkpoint-dir", default="models/cgan")
    args = parser.parse_args()
    train(args.manifest, args.epochs, args.batch_size, args.checkpoint_dir)
