"""Manifest-backed paired audio/image dataset."""
from pathlib import Path
import pandas as pd
import numpy as np
import tensorflow as tf
from PIL import Image
from .audio import extract_audio_features

IMAGE_SIZE = 128
FEATURE_DIM = 40 * 32


def load_manifest(manifest_path: str | Path) -> pd.DataFrame:
    manifest_path = Path(manifest_path).resolve()
    df = pd.read_csv(manifest_path)
    required = {"audio_path", "image_path"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Manifest is missing columns: {sorted(missing)}")
    root = manifest_path.parent.parent
    for col in ("audio_path", "image_path"):
        df[col] = df[col].map(lambda p: str((root / p).resolve()) if not Path(str(p)).is_absolute() else str(Path(str(p)).resolve()))
    if df.empty:
        raise ValueError("Manifest contains no rows")
    for col in ("audio_path", "image_path"):
        bad = [p for p in df[col] if not Path(p).is_file()]
        if bad:
            raise FileNotFoundError(f"Missing {col} file, e.g. {bad[0]}")
    return df


def load_pair(audio_path: str, image_path: str):
    features = extract_audio_features(audio_path)
    with Image.open(image_path) as im:
        im = im.convert("RGB").resize((IMAGE_SIZE, IMAGE_SIZE))
        image = np.asarray(im, dtype=np.float32) / 127.5 - 1.0
    return features.astype(np.float32), image


def make_dataset(manifest_path: str | Path, batch_size: int = 16, shuffle: bool = True):
    df = load_manifest(manifest_path)
    features, images = [], []
    for row in df.itertuples(index=False):
        f, im = load_pair(row.audio_path, row.image_path)
        features.append(f)
        images.append(im)
    x = np.asarray(features, dtype=np.float32)
    y = np.asarray(images, dtype=np.float32)
    ds = tf.data.Dataset.from_tensor_slices((x, y))
    if shuffle:
        ds = ds.shuffle(len(x), reshuffle_each_iteration=True)
    return ds.batch(batch_size).prefetch(tf.data.AUTOTUNE), len(x)
