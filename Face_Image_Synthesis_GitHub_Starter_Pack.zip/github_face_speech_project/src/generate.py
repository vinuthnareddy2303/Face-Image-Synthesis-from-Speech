"""Generate a synthetic face image from a speech recording."""
import argparse
from pathlib import Path
import numpy as np
import tensorflow as tf
from PIL import Image
from .audio import extract_audio_features
from .models import build_generator, LATENT_DIM


def generate(audio, checkpoint_dir="models/cgan", output="outputs/generated_face.png"):
    generator = build_generator()
    checkpoint = tf.train.Checkpoint(generator=generator)
    latest = tf.train.latest_checkpoint(checkpoint_dir)
    if latest is None:
        raise FileNotFoundError(f"No TensorFlow checkpoint found in {checkpoint_dir}. Train the model first.")
    checkpoint.restore(latest).expect_partial()
    features = extract_audio_features(audio)[None, :]
    noise = np.random.normal(size=(1, LATENT_DIM)).astype(np.float32)
    image = generator([features, noise], training=False)[0].numpy()
    image = np.clip((image + 1.0) * 127.5, 0, 255).astype(np.uint8)
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(image).save(path)
    print(f"Saved synthetic image to {path.resolve()}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", required=True)
    parser.add_argument("--checkpoint-dir", default="models/cgan")
    parser.add_argument("--output", default="outputs/generated_face.png")
    args = parser.parse_args()
    generate(args.audio, args.checkpoint_dir, args.output)
