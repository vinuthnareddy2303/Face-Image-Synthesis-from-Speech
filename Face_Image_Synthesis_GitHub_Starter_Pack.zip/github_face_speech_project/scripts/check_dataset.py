import argparse
from src.dataset import load_manifest

parser = argparse.ArgumentParser(description="Validate the paired audio/image manifest.")
parser.add_argument("--manifest", default="data/manifest.csv")
args = parser.parse_args()
df = load_manifest(args.manifest)
print(f"Manifest OK: {len(df)} paired records")
print("Columns:", ", ".join(df.columns))
