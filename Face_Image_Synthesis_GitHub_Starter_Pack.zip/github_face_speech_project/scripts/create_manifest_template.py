from pathlib import Path
import csv
out = Path("data/manifest.csv")
out.parent.mkdir(exist_ok=True)
with out.open("w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["audio_path", "image_path", "speaker_id"])
    writer.writerow(["dataset/audio/speaker001_clip001.wav", "dataset/faces/speaker001_clip001.jpg", "speaker001"])
print(f"Created template at {out}. Replace the example row with real paired files.")
