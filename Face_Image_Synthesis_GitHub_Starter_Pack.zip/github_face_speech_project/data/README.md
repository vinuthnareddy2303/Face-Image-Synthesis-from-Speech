# Dataset setup

The dataset is intentionally not redistributed in this repository. The project materials refer to VoxCeleb and VGGFace; access and permitted use depend on each dataset's official terms. Obtain data only from the official source and check its current licence/consent conditions before use.

Create `data/manifest.csv` with columns:
- `audio_path`: path to a speech recording (WAV recommended).
- `image_path`: path to the corresponding face image.
- `speaker_id`: optional speaker label for auditing/splitting.

Each row must be a true audio/image pair for the same source example. Keep speaker IDs disjoint across training and evaluation splits. Never commit the raw datasets or private recordings to a public repository.
