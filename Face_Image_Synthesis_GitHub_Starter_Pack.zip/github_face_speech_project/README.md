# Face Image Synthesis from Speech Using Conditional Generative Adversarial Network (cGAN)

A research/academic project exploring speech-conditioned facial image synthesis. The repository contains a reproducible **starter implementation** of a conditional GAN pipeline, dataset-manifest tools, documentation, and the project report/presentation supplied by the team.

> **Important:** A voice does not uniquely determine a person's face. Generated images are statistical model outputs, not reliable identity evidence. Do not use this system to identify, authenticate, profile, or make decisions about a real person.

## Team
- **Batch:** A4
- Bussa Akshita — 23BK1A6612
- Narra Ashwini — 23BK1A6637
- Mylaram Vinuthna Reddy — 23BK1A6633
- **Guide:** Dr. K. Rajiv, Professor
- **Department:** CSE (AI & ML), St. Peter's Engineering College

## Project overview
The pipeline extracts a fixed-length acoustic representation from a `.wav` recording (MFCC features), combines it with a random latent vector, and conditions a generator to produce a face-shaped image. A discriminator receives both the image and acoustic condition and learns to distinguish real paired images from generated images.

### Workflow
1. Prepare paired speech and face-image examples.
2. Create `data/manifest.csv` containing audio path, image path, and optional speaker label.
3. Extract MFCC features and resize/normalize face images.
4. Train the conditional generator and discriminator.
5. Generate an image from a new speech recording using the trained generator.

## Repository structure
```text
src/
  audio.py          MFCC feature extraction
  dataset.py        CSV manifest loading and preprocessing
  models.py         Conditional generator and discriminator
  train.py          cGAN training loop
  generate.py       Generate an image from a WAV file
scripts/
  create_manifest_template.py
  check_dataset.py
data/
  manifest.example.csv
  README.md
models/             Checkpoints are created here (not committed)
outputs/            Generated images are saved here (not committed)
docs/
  Original_Project_Report.docx
  Project_Abstract.docx
  Previous_Review_Presentation.pptx
  SYSTEM_ARCHITECTURE.md
  DATASET_AND_ETHICS.md
```

## Requirements
- Python 3.10 or 3.11 recommended
- TensorFlow 2.15+ (GPU optional)
- VoxCeleb or another appropriately licensed dataset with paired audio/image samples

Install:
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Prepare the dataset
The dataset is **not included**. Obtain it through its official access process and follow its licence/terms. Organize files locally, then create `data/manifest.csv` with these columns:

```csv
audio_path,image_path,speaker_id
/path/to/audio_001.wav,/path/to/face_001.jpg,speaker_001
```

Paths may be absolute or relative to the repository root. Each row must represent a genuinely paired audio/image example. Do not randomly pair unrelated speakers. See [data/README.md](data/README.md).

Check the manifest:
```bash
python scripts/check_dataset.py --manifest data/manifest.csv
```

## Train
```bash
python -m src.train --manifest data/manifest.csv --epochs 50 --batch-size 16
```

The script saves TensorFlow checkpoints under `models/`.

## Generate
After training:
```bash
python -m src.generate --audio path/to/test.wav --checkpoint-dir models/cgan --output outputs/generated_face.png
```

The model produces a synthetic 128×128 RGB image. Quality depends on the size, diversity, and correctness of the paired training data. Training on a small dataset is only for pipeline testing and should not be presented as a validated result.

## Evaluation and reporting
Report held-out evaluation results only after running a documented experiment. Keep speaker identities separated between training and test sets to reduce leakage. Do not copy the accuracy figures in older draft slides as results of this starter code; those values require independent verification against the actual experiment and evaluation protocol.

## Limitations
- Speech-to-face mapping is inherently ambiguous and may encode dataset bias.
- A generated face should not be interpreted as the speaker's actual appearance.
- The included code is a baseline research scaffold, not a validated biometric system.
- Identity-recognition accuracy is not implemented as a verified module in this starter repository.

## Academic integrity
The report and previous review presentation are included as supplied project documents. The Python implementation in `src/` is a clean, modular baseline and should be tested, adapted, and described accurately by the project team. Add experiment logs, screenshots, and actual results only after producing them.

## Citation
See the references section in `docs/Original_Project_Report.docx` and the literature survey in the previous review presentation.
