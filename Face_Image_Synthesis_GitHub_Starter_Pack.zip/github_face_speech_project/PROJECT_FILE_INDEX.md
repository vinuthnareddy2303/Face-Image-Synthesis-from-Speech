# Files included

- `README.md`: overview, installation, commands, limitations.
- `requirements.txt`: Python dependencies.
- `src/`: modular baseline code for preprocessing, cGAN models, training, and generation.
- `scripts/`: dataset-manifest utilities.
- `data/manifest.example.csv`: example manifest format (no dataset included).
- `docs/Original_Project_Report.docx`: supplied project report.
- `docs/Project_Abstract.docx`: supplied abstract.
- `docs/Previous_Review_Presentation.pptx`: supplied review presentation.
- `docs/SYSTEM_ARCHITECTURE.md`: architecture flow.
- `docs/DATASET_AND_ETHICS.md`: dataset and responsible-use notes.
- `GitHub_Project_Presentation.pptx`: repository overview presentation.
