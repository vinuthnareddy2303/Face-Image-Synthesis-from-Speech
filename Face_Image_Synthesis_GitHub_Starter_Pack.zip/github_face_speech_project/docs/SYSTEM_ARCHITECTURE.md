# System architecture

```mermaid
flowchart TD
    A[Paired speech and face dataset] --> B[Manifest validation]
    B --> C[Audio preprocessing: MFCC]
    B --> D[Face preprocessing: RGB resize and normalization]
    C --> E[Audio condition vector]
    E --> F[Generator + random latent noise]
    F --> G[Generated face image]
    D --> H[Discriminator]
    G --> H
    E --> H
    H --> I[Adversarial losses]
    I --> J[Update Generator and Discriminator]
    J --> F
    G --> K[Saved synthetic image]
```

The generator learns a conditional mapping from acoustic features and latent noise to an image. The discriminator receives a candidate image and the same acoustic condition. This is a baseline architecture; its output quality and generalization must be established experimentally.
