# Dataset, evaluation, and responsible use

## Data
Use only datasets for which the team has legitimate access and permission. The project drafts refer to VoxCeleb and VGGFace. Confirm the current terms directly with the dataset providers. Do not publish dataset files, private audio, face images, or identifying metadata in this public repository.

## Evaluation
Create speaker-independent train/validation/test partitions. Record the exact split procedure, dataset version, preprocessing settings, random seeds, model configuration, and checkpoint. Report only metrics produced by the current implementation and a reproducible evaluation script. Do not present historical draft accuracy values as results of this code without reproducing the experiment.

## Responsible use
A person's voice does not uniquely specify their face. Generated faces can reflect correlations and biases in the training data and must not be treated as an actual portrait, identity verification, or biometric evidence. Obtain appropriate consent for data use and clearly label generated images as synthetic.
